This code is written by Yangyang Xu based on the paper:
  M.-J. Lai, Y. Xu, W. Yin., Improved iteratively reweighted least squares for unconstrained smoothed lq     minimization, SIAM Journal on Numerical Analysis, 5(2), 927-957, 2013. 

To start, just run
>> test_IRucLq